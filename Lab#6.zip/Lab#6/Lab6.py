import os
import requests
import pandas as pd
from textblob import TextBlob
import streamlit as st

# Функция для получения популярных фильмов
def get_popular_movies(api_key, page=1):
    url = f"https://api.themoviedb.org/3/movie/popular?api_key={api_key}&language=en-US&page={page}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        st.error(f"Ошибка {response.status_code}: {response.text}")
        return None


# Функция для получения отзывов к фильму по его ID
def get_movie_reviews(api_key, movie_id):
    url = f"https://api.themoviedb.org/3/movie/{movie_id}/reviews?api_key={api_key}&language=en-US"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json().get("results", [])
    else:
        st.error(f"Ошибка {response.status_code}: {response.text}")
        return []


# Анализ тональности с использованием TextBlob
def analyze_sentiment(reviews):
    sentiments = []
    for review in reviews:
        analysis = TextBlob(review)
        if analysis.sentiment.polarity > 0:
            sentiments.append("positive")
        elif analysis.sentiment.polarity < 0:
            sentiments.append("negative")
        else:
            sentiments.append("neutral")
    return sentiments


# Основной процесс с Streamlit
st.title("Анализ тональности отзывов к фильмам")

# Ввод API-ключа
api_key = os.getenv("TMDB_API_KEY") or st.text_input("Введите ваш API-ключ от TMDB", type="password")

if api_key:
    # Получение популярных фильмов
    popular_movies = get_popular_movies(api_key)

    if popular_movies:
        movie_options = {movie["title"]: movie["id"] for movie in popular_movies["results"]}
        selected_movies = st.multiselect("Выберите фильмы для анализа", options=list(movie_options.keys()))

        if selected_movies:
            movies_data = []
            for movie_title in selected_movies:
                movie_id = movie_options[movie_title]
                reviews = get_movie_reviews(api_key, movie_id)
                reviews_text = [review["content"] for review in reviews]
                sentiments = analyze_sentiment(reviews_text)

                movies_data.append({
                    "title": movie_title,
                    "reviews": reviews_text,
                    "positive": sentiments.count("positive"),
                    "negative": sentiments.count("negative"),
                    "neutral": sentiments.count("neutral")
                })

            # Создание DataFrame
            results_df = pd.DataFrame(movies_data, columns=["title", "positive", "negative", "neutral"])

            # Отображение таблицы
            st.subheader("Результаты анализа")
            st.dataframe(results_df.set_index("title"))

            # Отображение графика
            st.bar_chart(results_df.set_index("title"))

            # Отображение комментариев
            for movie in movies_data:
                st.subheader(f"Отзывы к фильму: {movie['title']}")
                for review in movie["reviews"]:
                    st.write(review)

else:
    st.info("Введите ваш API-ключ, чтобы начать анализ.")
